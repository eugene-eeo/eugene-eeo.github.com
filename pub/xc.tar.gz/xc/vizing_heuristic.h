#ifndef VIZING_H
#define VIZING_H

#include "graph.h"

int vizing_heuristic(graph* g, int* P);

#endif /* VIZING_H */
