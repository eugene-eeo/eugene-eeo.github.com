#!/bin/bash

cd eeojun
time ./solution-step1 $(cat setups/setup-$1.txt)
time ./solution-step4 $(cat setups/setup-$1.txt)
