#!/bin/bash

cd eeojun
time ./solution-step4 $(cat setups/setup-$1.txt)
